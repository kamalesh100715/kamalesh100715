import json
import boto3
import os

def lambda_handler(event, context):
    try:
        print("Received event: " + json.dumps(event, indent=2))
        
        # Validate that the event contains the expected 'Records' key
        if 'Records' not in event or not event['Records']:
            raise ValueError("Event does not contain 'Records' or 'Records' is empty")
        
        # Get the S3 bucket and object key from the event
        input_bucket = 'input1bucket'
        input_key = event['Records'][0]['s3']['object']['key']
        input_file = f"s3://{input_bucket}/{input_key}"
        
        # Get the MediaConvert client
        mediaconvert = boto3.client('mediaconvert', endpoint_url=os.environ['MEDIACONVERT_ENDPOINT'])
        
        # MediaConvert job settings
        job_settings = {
            'Role': os.environ['MEDIACONVERT_ROLE'],
            'Settings': {
                'Inputs': [
                    {
                        'FileInput': input_file
                    }
                ],
                'OutputGroups': [
                    {
                        'OutputGroupSettings': {
                            'Type': 'HLS_GROUP_SETTINGS',
                            'HlsGroupSettings': {
                                'Destination': f"s3://output2bucket/hls/"
                            }
                        },
                        'Outputs': [
                            {
                                'ContainerSettings': {
                                    'Container': 'M3U8'
                                },
                                'VideoDescription': {
                                    'CodecSettings': {
                                        'Codec': 'H_264'
                                    }
                                },
                                'AudioDescriptions': [
                                    {
                                        'CodecSettings': {
                                            'Codec': 'AAC'
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }
        
        # Create MediaConvert job
        response = mediaconvert.create_job(**job_settings)
        print(f"MediaConvert job created: {response['Job']['Id']}")
        return {
            'statusCode': 200,
            'body': json.dumps('MediaConvert job created')
        }
    except Exception as e:
        print(f"Error creating MediaConvert job: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error creating MediaConvert job: {e}")
        }
